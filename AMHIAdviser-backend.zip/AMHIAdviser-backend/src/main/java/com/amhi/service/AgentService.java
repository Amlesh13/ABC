/**
 * 
 */
package com.amhi.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.amhi.model.Agent;
import com.amhi.model.Feedback;
import com.amhi.model.Product;
import com.amhi.model.ProductCapture;
import com.amhi.model.QuestionResponse;
import com.amhi.model.Questions;

/**
 * @author Amleshkumar.Jha
 *
 */

public interface AgentService {
	
	public List validateLoginPass(Agent agent);
	public List questionsOptions(Questions questions);
	public boolean checkAppVersion(String myVersion);
	public List<QuestionResponse> getQuestionRespoonse(List<QuestionResponse> questionResponse);
	public List<Product> productName(Product product);
	public Feedback feedbackData(Feedback feedback);
	public List pcData(ProductCapture productCapture);
	
	
}
