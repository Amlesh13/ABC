/**
 * 
 */
package com.amhi.service;
import java.util.List;
import java.util.ResourceBundle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amhi.dao.AgentDao;
import com.amhi.model.Agent;
import com.amhi.model.Constants;
import com.amhi.model.Feedback;
import com.amhi.model.Product;
import com.amhi.model.ProductCapture;
import com.amhi.model.QuestionResponse;
import com.amhi.model.Questions;

/**
 * @author Amleshkumar.Jha
 *
 */
@Service
public class AgentServiceImpl implements AgentService
{
		@Autowired
		private AgentDao agentDao;
		ResourceBundle res = ResourceBundle.getBundle(Constants.RESOURCE_BUNDLE_NAME);
		
		@SuppressWarnings("unchecked")
		public List<Agent> validateLoginPass(Agent agent){
			List list=null;
			boolean bSuccess = false;
			String role = "";
			System.out.println("service layer is ");
		
			try {		
				if(agent.getAgentId()!= null && agent.getMobileNo()!= null){
					System.out.println("find agent id is:");
					list= agentDao.validatePassword(agent);
					System.out.println("agentId and Mobile number is service layer: "+list );
					
					if(list!=null)
					{
						System.out.println("if running");
						bSuccess = true;
					}else{
						role = "logIn Failed";
					}
				}
			} catch (Exception e) {
		
				System.out.println(e);
			}
			
			return list;
		}
		
		@SuppressWarnings("unchecked")
		public List<QuestionResponse> questionsOptions(Questions questions)
		{	
			List list=null;
			list=agentDao.questionsOptions(questions);
			
		System.out.println("method called");

		return list;
		}

		/**
		 * Check the application version with apk version.
		 * 
		 * @param myVersion
		 * @return {@code TRUE} if apk version and app version are same else return {@code FALSE}.
		 */

		public boolean checkAppVersion(String myVersion) {

			String latestVersion = res.getString("latestVersion");
			if (latestVersion.equals(myVersion)) {
				return true;
			} else {
				return false;
			}
		}
	
		@SuppressWarnings("unchecked")
		public List<QuestionResponse> getQuestionRespoonse(List<QuestionResponse> questionResponse)
		{ 
			System.out.println("got response");
		//	List list=null;
		    // list=agentDao.segmentData(questionResponse);		
			
			String s=null;
			s =agentDao.segmentData(questionResponse);		
			  
			 return questionResponse;
	
		}
		
		public List<Product> productName(Product product)
		{
	    
			List<Product> p=agentDao.product(product);		
	        System.out.println("product dao called");
	      
	        return p;
		}
	
		@SuppressWarnings("unchecked")
		public Feedback feedbackData(Feedback feedback)
		{ 
			feedback=agentDao.feedback(feedback);
				
		return feedback;
		}
		
		@SuppressWarnings("unchecked")
		public List<ProductCapture> pcData(ProductCapture productCapture){
			
			List<ProductCapture> lst=agentDao.pcdata(productCapture);
			return lst;
		}
	}