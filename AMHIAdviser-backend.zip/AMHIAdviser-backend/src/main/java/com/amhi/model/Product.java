/**
 * 
 */
package com.amhi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * @author Amleshkumar.Jha
 *
 */
@Entity
public class Product {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int pId;
	
	@Column
	private String Product_Name;
	
	@Column
	private double Product_Priority;

	@Column
	private String segments;

	@Column
	private String sum_insured;
	@Column
	private String sales_pitch;
	
	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public String getProduct_Name() {
		return Product_Name;
	}

	public void setProduct_Name(String product_Name) {
		Product_Name = product_Name;
	}

	public double getProduct_Priority() {
		return Product_Priority;
	}

	public void setProduct_Priority(double obj) {
		Product_Priority = obj;

	}

	public String getSegments() {
		return segments;
	}

	public void setSegments(String segments) {
		this.segments = segments;
	}

	public String getSum_insured() {
		return sum_insured;
	}

	public void setSum_insured(String sum_insured) {
		this.sum_insured = sum_insured;
	}

	public String getSales_pitch() {
		return sales_pitch;
	}

	public void setSales_pitch(String sales_pitch) {
		this.sales_pitch = sales_pitch;
	}




}
