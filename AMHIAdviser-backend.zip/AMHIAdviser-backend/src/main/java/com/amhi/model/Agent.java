/**
 * 
 */
package com.amhi.model;

/**
 * @author Amleshkumar.Jha
 *
 */
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;

@Entity
@Table(name = "AGENT")

public class Agent implements Serializable {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name = "USERS_ID")
	private String agentId;
	
	@Column(name = "FIRST_NAME")
	private String firstName;
	
	@Column(name = "LAST_NAME")
	private String lastName;
	
	@Column(name = "MOBILE_NO")
	private String mobileNo;


	@Column(name = "EMAIL_ID")
	private String emailId;
	
	@Column(name = "REG_DATE")
	private Date regDate;
	
	@Column(name = "REG_EXP_DATE")
	private Date regExpDate;
	
	@Column(name = "BRANCH")
	private String branch;
	
	@Column(name = "BRANCH_CITY")
	private String branchCity;
	
	@Column(name = "BRANCH_MGR_NAME")
	private String branchMgrName;
	
	@Column(name = "BRANCH_MGR_EMAIL")
	private String branchMgrEmail;
	
	@Column(name = "BRANCH_MGR_MOBILE")
	private String branchMgrMobileNo;
	
	@Column(name = "REGISTER_FLAG")
	private Integer registerFlag;
	
	@Column(name = "DOB")
	private Date dateOfBirth;
	
	@Column(name = "INITIATIVE_CD")
	private String initiativeCd;
	
	@Column(name = "TERMINATE_FLAG")
	private Integer terminateFlag;
	
	@Column(name = "ONE_LAKH_ENABLE_FLAG")
	private Integer oneLakhEnableFlag;
	
	@Column(name = "LAST_UPDATE_DATE")
	private Date lastUpdate;	
	
	private String errorMessage;
	private ArrayList errorMessageList;
	
	@Column(name="CHANNEL_CODE")
	private String channelCode;
	
	@Column(name="relaxed_days")
	private String relaxed_days;
/*
	@Column(name="maxValue")
	private double maxValue;
	
		public double getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(double maxValue) {
		this.maxValue = maxValue;
	}
*/
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public Date getRegExpDate() {
		return regExpDate;
	}

	public void setRegExpDate(Date regExpDate) {
		this.regExpDate = regExpDate;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getBranchCity() {
		return branchCity;
	}

	public void setBranchCity(String branchCity) {
		this.branchCity = branchCity;
	}

	public String getBranchMgrName() {
		return branchMgrName;
	}

	public void setBranchMgrName(String branchMgrName) {
		this.branchMgrName = branchMgrName;
	}

	public String getBranchMgrEmail() {
		return branchMgrEmail;
	}

	public void setBranchMgrEmail(String branchMgrEmail) {
		this.branchMgrEmail = branchMgrEmail;
	}

	public String getBranchMgrMobileNo() {
		return branchMgrMobileNo;
	}

	public void setBranchMgrMobileNo(String branchMgrMobileNo) {
		this.branchMgrMobileNo = branchMgrMobileNo;
	}

	public Integer getRegisterFlag() {
		return registerFlag;
	}

	public void setRegisterFlag(Integer registerFlag) {
		this.registerFlag = registerFlag;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getInitiativeCd() {
		return initiativeCd;
	}

	public void setInitiativeCd(String initiativeCd) {
		this.initiativeCd = initiativeCd;
	}

	public Integer getTerminateFlag() {
		return terminateFlag;
	}

	public void setTerminateFlag(Integer terminateFlag) {
		this.terminateFlag = terminateFlag;
	}

	public Integer getOneLakhEnableFlag() {
		return oneLakhEnableFlag;
	}

	public void setOneLakhEnableFlag(Integer oneLakhEnableFlag) {
		this.oneLakhEnableFlag = oneLakhEnableFlag;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public ArrayList getErrorMessageList() {
		return errorMessageList;
	}

	public void setErrorMessageList(ArrayList errorMessageList) {
		this.errorMessageList = errorMessageList;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getRelaxed_days() {
		return relaxed_days;
	}

	public void setRelaxed_days(String relaxed_days) {
		this.relaxed_days = relaxed_days;
	}



	@Override
	public String toString() {
		return "Agent [id=" + id + ", agentId=" + agentId + ", firstName="
				+ firstName + ", lastName=" + lastName + ", mobileNo="
				+ mobileNo + ", emailId=" + emailId + ", regDate=" + regDate
				+ ", regExpDate=" + regExpDate + ", branch=" + branch
				+ ", branchCity=" + branchCity + ", branchMgrName="
				+ branchMgrName + ", branchMgrEmail=" + branchMgrEmail
				+ ", branchMgrMobileNo=" + branchMgrMobileNo
				+ ", registerFlag=" + registerFlag + ", dateOfBirth="
				+ dateOfBirth + ", initiativeCd=" + initiativeCd
				+ ", terminateFlag=" + terminateFlag + ", oneLakhEnableFlag="
				+ oneLakhEnableFlag + ", lastUpdate=" + lastUpdate
				+ ", errorMessage=" + errorMessage + ", errorMessageList="
				+ errorMessageList + ", channelCode=" + channelCode
				+ ", relaxed_days=" + relaxed_days + "]";
	}


	
	
	}
