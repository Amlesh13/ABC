/**
 * 
 */
package com.amhi.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author Amleshkumar.Jha
 *
 */
@Entity
@Table(name = "Questions")
public class Questions {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int quesId;
	
	@Column
	private String question;
	
	@Column
	private String choose;
	
	@OneToMany(cascade = CascadeType.ALL)
	private List<QuestionsOptions> questtionOptions;
	
	public List<QuestionsOptions> getQuesttionOptions() {
		return questtionOptions;
	}
	public void setQuesttionOptions(List<QuestionsOptions> questtionOptions) {
		this.questtionOptions = questtionOptions;
	}
	
	public int getQuesId() {
		return quesId;
	}
	public void setQuesId(int quesId) {
		this.quesId = quesId;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getChoose() {
		return choose;
	}
	public void setChoose(String choose) {
		this.choose = choose;
	}
	
	@Override
	public String toString() {
		return "Questions [quesId=" + quesId + ", question=" + question
				+ ", choose=" + choose + "]";
	}
	
	
	
	
	

}
