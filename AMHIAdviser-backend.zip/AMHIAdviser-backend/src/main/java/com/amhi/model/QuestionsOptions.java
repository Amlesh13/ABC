/**
 * 
 */
package com.amhi.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author Amleshkumar.Jha
 *
 */

@Entity
@Table(name="QuestionsOptions")
public class QuestionsOptions {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
 
    @JoinColumn(name="quesId")
 	private int quesId;
    
	@Column
    private int optionid;
	
	@Column
	private String option;
	
	@Column
	private double segment_One;
	@Column
	private double segment_Two;
	@Column
	private double segment_Three;
	@Column
	private double segment_Four;

	@ManyToOne
	private Questions questions;
	
	public Questions getQuestions() {
		return questions;
	}
	public void setQuestions(Questions questions) {
		this.questions = questions;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public int getQuesId() {
		return quesId;
	}
	public void setQuesId(int quesId) {
		this.quesId = quesId;
	}
	public int getOptionid() {
		return optionid;
	}
	public void setOptionid(int optionid) {
		this.optionid = optionid;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}
	public double getSegment_One() {
		return segment_One;
	}
	public void setSegment_One(double segment_One) {
		this.segment_One = segment_One;
	}
	public double getSegment_Two() {
		return segment_Two;
	}
	public void setSegment_Two(double segment_Two) {
		this.segment_Two = segment_Two;
	}
	public double getSegment_Three() {
		return segment_Three;
	}
	public void setSegment_Three(double segment_Three) {
		this.segment_Three = segment_Three;
	}
	public double getSegment_Four() {
		return segment_Four;
	}
	public void setSegment_Four(double segment_Four) {
		this.segment_Four = segment_Four;
	}

	@Override
	public String toString() {
		return "QuestionsOptions [id=" + id + ", quesId=" + quesId
				+ ", optionid=" + optionid + ", option=" + option
				+ ", segment_One=" + segment_One + ", segment_Two="
				+ segment_Two + ", segment_Three=" + segment_Three
				+ ", segment_Four=" + segment_Four + ", questions=" + questions
				+ "]";
	}

	
	
	}
