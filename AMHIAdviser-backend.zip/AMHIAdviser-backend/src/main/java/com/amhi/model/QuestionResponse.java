/**
 * 
 */
package com.amhi.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Amleshkumar.Jha
 *
 */

public class QuestionResponse {

	private String quesId;
//	private String agentId;
	private String question;
	private List<OptionResponse> options;
	private List<String>  ansId=new ArrayList<String>();
	private String choose;
	
	public String getQuesId() {
		return quesId;
	}
	
	/*public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
*/
	public void setQuesId(String quesId) {
		this.quesId = quesId;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public List<OptionResponse> getOptions() {
		return options;
	}
	public void setOptions(List<OptionResponse> options) {
		this.options = options;
	}
	public List<String> getAnsId() {
		return ansId;
	}
	public void setAnsId(List<String> ansId) {
		this.ansId = ansId;
	}
	public String getChoose() {
		return choose;
	}
	public void setChoose(String choose) {
		this.choose = choose;
	}
	
}
