/**
 * 
 */
package com.amhi.model;

import java.util.ResourceBundle;

/**
 * @author Amleshkumar.Jha
 * This class contains constants used across the application
 */
public class Constants {

	public static final String RESOURCE_BUNDLE_NAME = "resource";


	static{
		ResourceBundle res = ResourceBundle.getBundle(Constants.RESOURCE_BUNDLE_NAME);
		}

}
