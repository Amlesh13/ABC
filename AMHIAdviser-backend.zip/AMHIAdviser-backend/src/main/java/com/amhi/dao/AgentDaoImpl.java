/**
 * 
 */
package com.amhi.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.amhi.model.Agent;
import com.amhi.model.Feedback;
import com.amhi.model.OptionResponse;
import com.amhi.model.Product;
import com.amhi.model.ProductCapture;
import com.amhi.model.QuestionResponse;
import com.amhi.model.Questions;

/**
 * @author Amleshkumar.Jha
 *
 */
@Transactional
@Scope(value="prototype", proxyMode = ScopedProxyMode.TARGET_CLASS)
@Repository("AgentDao")
public class AgentDaoImpl extends AbstractDao<Integer, Agent> implements AgentDao
{
	@Resource(name="sessionFactory")
	protected SessionFactory sessionFactory;

	 String agentId="";

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public List validatePassword(Agent agent) {

		String sql = "from Agent where agentId = :agentId and mobileNo= :mobileNo";
		List<Agent> lst = getSession().createQuery(sql).setParameter("agentId", agent.getAgentId()).setParameter("mobileNo", agent.getMobileNo()).list();

		Iterator it = lst.iterator();

		agentId=agent.getAgentId();

		System.out.println("the object is"+this.hashCode());
		return lst;
	}	

	public List<QuestionResponse> questionsOptions(Questions questions)

	{

		String sql= "SELECT questions.quesid, questions.question,questions.choose,array_to_string(array_agg(questionsoptions.optionid || '#' ||questionsoptions.option), '@@@') as p FROM questions INNER JOIN questionsoptions ON questions.quesid = questionsoptions.quesid GROUP BY questions.quesid;";
		List<Object[]> lst =  getSession().createSQLQuery(sql).list();
		List<QuestionResponse> list = new ArrayList<QuestionResponse>();

		for(Object[] obj : lst){
			System.out.println("obj ::::::::"+obj[0]);
			System.out.println("option ::::"+obj[3]);
			QuestionResponse qObj = new  QuestionResponse();
			qObj.setQuesId(obj[0]!=null?obj[0].toString():"");
			qObj.setQuestion(obj[1].toString());
			qObj.setChoose(obj[2].toString());
			List<OptionResponse> olist = new ArrayList<OptionResponse>();
			if(obj[3]!=null)
				for(String str : obj[3].toString().split("@@@")){
					String[] questionId_Option = str.split("#"); 
					OptionResponse oObj = new OptionResponse();
					oObj.setOptionid(questionId_Option[0]);
					oObj.setOption(questionId_Option[1]);
					olist.add(oObj);
				}
			list.add(qObj);
			qObj.setOptions(olist);
		}
		return list;
	}

	String segmentValue="";
	double max=0.0;

//	public List<QuestionResponse> segmentData(List<QuestionResponse> questionResponse)
	
	public String segmentData(List<QuestionResponse> questionResponse)
	
	{

		String sql="";
		List<Object[]> lst1=null;
		double segOne=0.0;
		double segTwo=0.0;
		double segThree=0.0;
		double segFour=0.0;

		double seg1=0.0;
		double seg2=0.0;
		double seg3=0.0;
		double seg4=0.0;

		for(QuestionResponse ob:questionResponse){
			if(ob.getAnsId()!=null && ob.getAnsId().size()>0)
			{
				System.out.println("que id is:"+ob.getQuesId());
				//agentId=ob.getAgentId();


				for(int i=0;i<ob.getAnsId().size();i++)
				{
					sql= "select questionsoptions.segment_one,questionsoptions.segment_two,questionsoptions.segment_three,questionsoptions.segment_four,questionsoptions.weight from Questionsoptions WHERE quesid = +"+ob.getQuesId()+" "+" AND optionid ="+""+ob.getAnsId().get(i)+"";
					lst1 =  getSession().createSQLQuery(sql).list();
					int size=lst1.size();
					System.out.println("size is:" +size);
					for(Object[] obj : lst1){
						System.out.println("segment1 ::::::::"+obj[0]);
						System.out.println("segment2 ::::"+obj[1]);
						System.out.println("segment3 ::::::::"+obj[2]);
						System.out.println("segment4 ::::"+obj[3]);
						System.out.println("weight is ::::"+obj[4]);
                       
						int percent=(int) obj[4];
						
						seg1 =(((double) obj[0]*percent)/100);
						seg2 =(((double) obj[1]*percent)/100);
						seg3 =(((double) obj[2]*percent)/100);
						seg4 =(((double) obj[3]*percent)/100);

						segOne=segOne+seg1;
						segTwo=segTwo+seg2;
						segThree=segThree+seg3;
						segFour=segFour+seg4;
					}

				}
				System.out.println("loop out");
			}

			System.out.println("seg one:  " +segOne);
			System.out.println("seg two: " +segTwo);
			System.out.println("seg three: " +segThree);
			System.out.println("seg four:  " +segFour);

			max=((segOne>segTwo)&&(segOne>segThree)&&(segOne>segFour))?segOne:(((segTwo>segThree)&&(segTwo>segFour))?segTwo:(segThree>segFour)?segThree:segFour);

			System.out.println("the object is"+this.hashCode());

			System.out.println("Largest No is :" +max);
			if(max==segOne)
			{
				double segment_one=max;

				segmentValue="segment_one";
			System.out.println(segmentValue);
			}
			if(max==segTwo)
			{
				segmentValue="segment_two";
				System.out.println(segmentValue);
				
			}

			if(max==segThree)
			{
				segmentValue="segment_three";
				System.out.println(segmentValue);
				
			}

			if(max==segFour)
			{
				segmentValue="segment_four";
				System.out.println(segmentValue);
				
			}


		}
		return null;

	}       
	public List<Product> product(Product product)   	
	{
		String sql= "select * from product where pid in(1,5,9,13)";
		List<Object[]> lst =  getSession().createSQLQuery(sql).list();
		List<Product> list = new ArrayList<Product>();
		System.out.println("product is called");

		System.out.println("the object is"+this.hashCode());

		
		double[] pvalue= new double[5];

		double p1temp=0;
		double	 p1=0;

		double p2temp=0;
		double p2=0;

		double p3temp=0;
		double p3=0;

		double p4temp=0;
		double p4=0;

		String p="";
		for(Object[] ob: lst)
		{
			System.out.println("maximum segment is: " +max);

			System.out.println("product id is: "+ob[0]);
			System.out.println("product name is: "+ob[1]);
			System.out.println("product value is: "+ob[2]);

			Product product1=new Product();
			System.out.println("list is:"+ list.size());

			if(list.size()==0)
			{
				p1temp=(double) ob[2];
				p1=(double) p1temp;
				System.out.println("p1: "+p1);

				pvalue[0]=p1;
			}

			if(list.size()==1)
			{

				p2temp=(double) ob[2];
				p2=(int)p2temp;
				System.out.println("p2: "+p2);
				pvalue[1]=p2;
			}

			if(list.size()==2)
			{
				p3temp=(double) ob[2];
				p3=(int)p3temp;
				System.out.println("p3: "+p3);
				pvalue[2]=p3;
			}

			if(list.size()==3)
			{
				p4temp=(double) ob[2];
				p4=(int)p4temp;
				System.out.println("p4: "+p4);
				pvalue[3]=p4;
			}

			list.add(product1);
		}

		double distance =  Math.abs(pvalue[0] - max);
		int idx = 0;
		for(int c = 1; c < 4; c++){
			double cdistance =  Math.abs(pvalue[c] - max);
			if(cdistance < distance){
				idx = c;
				
				distance = cdistance;
			}
		}
		System.out.println("idx is " +idx);
		
		double theNumber = pvalue[idx];

		System.out.println("the nearest number is:" +theNumber);

		ProductCapture productCapture=new ProductCapture();

		product=new Product();

		String sql1= "select * from product WHERE product_priority = +"+theNumber+" AND segments ='"+segmentValue+"'";

		List<Object[]> lstp =  getSession().createSQLQuery(sql1).list();

		List list1 = new ArrayList();

		List list2 = new ArrayList();


		for(Object[] obj : lstp){

			product.setpId((int) obj[0]);
			product.setProduct_Name(obj[1].toString());
			product.setProduct_Priority((double) obj[2]);
			product.setSegments((String) obj[3]);
			product.setSum_insured((String) obj[4]);
			product.setSales_pitch((String)obj[5]);

			productCapture.setpId((int) obj[0]);
			productCapture.setProduct_Name(obj[1].toString());
			productCapture.setProduct_Priority((double) obj[2]);
			productCapture.setSegments((String) obj[3]);
			productCapture.setSum_insured((String) obj[4]);
			productCapture.setSales_pitch((String)obj[5]);

			list1.add(product);
			
			// this is for product capture
			list2.add(productCapture);
	

			 Date date = new Date();
			    String strDateFormat = "dd/MM/yyyy HH:mm:ss";
			    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
			    String formattedDate= dateFormat.format(date);
			    System.out.println("Current time of the day using Date 12 hour format: " + formattedDate);
			
			productCapture.setCapturedDate(formattedDate);
			productCapture.setAgentid(agentId);
			getSession().save(productCapture);
			
			System.out.println("product captured saved in database");
		} 
		System.out.println("product is called");
				
		Query query = getSession().createSQLQuery("update Agent set register_flag = :register_flag" + " where users_id = :users_id");
		query.setParameter("register_flag", 1);
		query.setParameter("users_id", agentId );
		int result = query.executeUpdate();

		System.out.println("Agent flag is updated when product shows");

		return  list1;
	}

	public List<ProductCapture> pcdata(ProductCapture productCapture)
	{
		
		//String lstp = "from ProductCapture where agentid ='"+agentId+"'";
		
		String lstp = "from ProductCapture t1 where t1.capturedDate = (select max(t2.capturedDate) from ProductCapture t2 where t2.agentid = '"+agentId+"')";
		
		List<ProductCapture> lst = getSession().createQuery(lstp).list();
		return  lst;
	
	}
	public Feedback feedback(Feedback feedback)
	{
		int product_id=feedback.getProductId();
		System.out.println("product id is :" +product_id);
		String disposition=feedback.getDisposition();

		System.out.println("Disposition is: " +disposition);
		int suminsuresd=feedback.getSumInsured();

		System.out.println("suminsured amount is: " +suminsuresd);

		String comString=feedback.getComment();

		System.out.println("comment is: " +comString);

		String time=feedback.getTime();

		System.out.println("Time is: " +time);

		try
		{

			//	 String sqlFeedback= "insert into feedback(productId,sumInsured,disposition,comment,time) values(+"+feedback.getProductId()+",+"+feedback.getSumInsured()+",+"+feedback.getDisposition()+",+"+feedback.getComment()+",+"+(String)feedback.getTime()+")";

			String sqlFeedback= "insert into feedback(productId,sumInsured,disposition,comment,time) values(+feedback.getProductId()+,+feedback.getSumInsured()+,+feedback.getDisposition(),+feedback.getComment()+,+(String)feedback.getTime()+)";
			System.out.println("quesrty ");

			getSession().save(sqlFeedback, feedback);
	
	    	//String sqldelete="delete from productcapture where agentid=:agentId";
		
			//Query query = getSession().createSQLQuery("delete from productcapture where agentid=:agentId");
		//	query.setParameter("agentid", agentId);
			//int result = query.executeUpdate();

			
			
		}

		catch(Exception exception)
		{
			exception.printStackTrace();
		}

		System.out.println("customer feedback data save in database");

		System.out.println("feedback agent id is:"+agentId);

		Query query = getSession().createSQLQuery("update Agent set register_flag = :register_flag" + " where users_id = :users_id");
		
		query.setParameter("register_flag", 0);
		query.setParameter("users_id", agentId );
		int result = query.executeUpdate();

	 	
		System.out.println("Agent flag is updated when feedback done");

		
		
		return feedback;

		
	}

	
	
	
}	
