/**
 * 
 */
package com.amhi.dao;

import java.util.List;

import com.amhi.model.Agent;
import com.amhi.model.Feedback;
import com.amhi.model.Product;
import com.amhi.model.ProductCapture;
import com.amhi.model.QuestionResponse;
import com.amhi.model.Questions;

/**
 * @author Amleshkumar.Jha
 *
 */
public interface AgentDao {
	
	public List validatePassword(Agent agent);
	public List  questionsOptions(Questions questions);
//	public List<QuestionResponse> segmentData(List<QuestionResponse> questionResponse);
	
	public String segmentData(List<QuestionResponse> questionResponse);
	
	public List<Product> product(Product product);
	public Feedback feedback(Feedback feedback);
	public List pcdata(ProductCapture productCapture);
	
	
	
	
}
