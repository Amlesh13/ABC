package com.amhi.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.amhi.model.Agent;
import com.amhi.model.Feedback;
import com.amhi.model.Product;
import com.amhi.model.ProductCapture;
import com.amhi.model.QuestionResponse;
import com.amhi.model.Questions;
import com.amhi.service.AgentService;

@Controller
@Scope(value="prototype", proxyMode = ScopedProxyMode.TARGET_CLASS)
@RequestMapping("/")
public class AgentLogInController {
	@Autowired
	AgentService agentService;
	
	@RequestMapping(value="/agentLogIn",method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List< Agent> validateLoginPass(@RequestBody Agent agent, HttpServletRequest httpServletRequest){
	
		System.out.println("agent id is:"+ agent.getAgentId() + "mobile "+agent.getMobileNo());
		List<Agent> agentList = agentService.validateLoginPass(agent);
		System.out.println("called");
	
		System.out.println("ghfgjddf::::" +httpServletRequest.getHeader("agentId"));
		
		return agentList;
	}
	
	@RequestMapping(value="/getQuestion",method=RequestMethod.GET)//,consumes=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<QuestionResponse> questionOptions(Questions  questions){
		
		System.out.println("questions url called");

	    List<QuestionResponse> questionList = agentService.questionsOptions(questions);
  	    
	    return questionList;
	}

	/**
	 *  This method is used to check App Version.
	 * @param myVersion
	
	 */
	
	@RequestMapping(value = "/checkAppVersion/{myVersion:.+}",  method = RequestMethod.GET)
	@ResponseBody
	public boolean checkVersion(@PathVariable String myVersion){
		
		System.out.println("check app version");
		boolean version=agentService.checkAppVersion(myVersion);	
		return version;
	}

	@RequestMapping(value = "/getData", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<QuestionResponse> questionResponse1(@RequestBody List<QuestionResponse> questionResponse,HttpServletResponse response)
	{	
		System.out.println("got question rsponse");
		List<QuestionResponse> questionResponse2=agentService.getQuestionRespoonse(questionResponse);
		
		response.addHeader("max", "10");
		
		return questionResponse2;
	}


	@RequestMapping(value="/getProduct",method=RequestMethod.GET)//,consumes=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<Product> questionOptions(Product  product,HttpServletResponse response){
		
		List<Product> productsList = agentService.productName(product);
	    
		System.out.println("product is called");
	
		System.out.println("max is:" +response.getHeader("max"));
	    
		
		return productsList;
	}

	@RequestMapping(value="/getfeedback", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody Feedback getFeedback(@RequestBody Feedback  feedback){
		
		Feedback feedbacks=agentService.feedbackData(feedback);
		System.out.println("Feedback called");

		
		return feedbacks;
	}
	
	@RequestMapping(value="/getCapturedProduct", method = RequestMethod.GET)//,consumes=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<ProductCapture> getCapturedProduct(ProductCapture productCapture){
		
		List<ProductCapture> pcData=agentService.pcData(productCapture);
	    System.out.println("product capture data called");
	    return pcData;
	
	}
}