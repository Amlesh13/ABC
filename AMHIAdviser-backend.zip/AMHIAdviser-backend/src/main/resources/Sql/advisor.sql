--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.2

-- Started on 2017-06-13 10:32:12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 2171 (class 1262 OID 83298)
-- Name: amhi; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE amhi WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE amhi OWNER TO postgres;

\connect amhi

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 1 (class 3079 OID 12387)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2173 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 185 (class 1259 OID 100443)
-- Name: agent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE agent (
    id integer NOT NULL,
    users_id character varying(255),
    branch character varying(255),
    branch_city character varying(255),
    branch_mgr_email character varying(255),
    branch_mgr_mobile character varying(255),
    branch_mgr_name character varying(255),
    channel_code character varying(255),
    dob timestamp without time zone,
    email_id character varying(255),
    errormessage character varying(255),
    errormessagelist bytea,
    first_name character varying(255),
    initiative_cd character varying(255),
    last_name character varying(255),
    last_update_date timestamp without time zone,
    mobile_no character varying(255),
    one_lakh_enable_flag integer,
    reg_date timestamp without time zone,
    reg_exp_date timestamp without time zone,
    register_flag integer,
    relaxed_days character varying(255),
    terminate_flag integer
);


ALTER TABLE agent OWNER TO postgres;

--
-- TOC entry 187 (class 1259 OID 100453)
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE employee (
    id integer NOT NULL,
    joining_date date NOT NULL,
    name character varying(50) NOT NULL,
    salary numeric(10,2) NOT NULL,
    ssn character varying(255) NOT NULL
);


ALTER TABLE employee OWNER TO postgres;

--
-- TOC entry 186 (class 1259 OID 100451)
-- Name: employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE employee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE employee_id_seq OWNER TO postgres;

--
-- TOC entry 2174 (class 0 OID 0)
-- Dependencies: 186
-- Name: employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE employee_id_seq OWNED BY employee.id;


--
-- TOC entry 192 (class 1259 OID 108731)
-- Name: feedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE feedback (
    id integer NOT NULL,
    productid integer,
    suminsured integer,
    disposition character varying(500),
    comment character varying(5000),
    "time" character varying(5000)
);


ALTER TABLE feedback OWNER TO postgres;

--
-- TOC entry 191 (class 1259 OID 100479)
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hibernate_sequence OWNER TO postgres;

--
-- TOC entry 188 (class 1259 OID 100459)
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE product (
    pid integer NOT NULL,
    product_name character varying(255),
    product_priority integer,
    segments character varying(25),
    sum_insured character varying(50),
    sales_pitch character varying(500)
);


ALTER TABLE product OWNER TO postgres;

--
-- TOC entry 189 (class 1259 OID 100464)
-- Name: questions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE questions (
    quesid integer NOT NULL,
    choose character varying(255),
    question character varying(255)
);


ALTER TABLE questions OWNER TO postgres;

--
-- TOC entry 190 (class 1259 OID 100472)
-- Name: questionsoptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE questionsoptions (
    id integer NOT NULL,
    option character varying(255),
    optionid integer,
    quesid integer NOT NULL,
    segment_four double precision,
    segment_one double precision,
    segment_three double precision,
    segment_two double precision
);


ALTER TABLE questionsoptions OWNER TO postgres;

--
-- TOC entry 2027 (class 2604 OID 100456)
-- Name: employee id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employee ALTER COLUMN id SET DEFAULT nextval('employee_id_seq'::regclass);


--
-- TOC entry 2159 (class 0 OID 100443)
-- Dependencies: 185
-- Data for Name: agent; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO agent (id, users_id, branch, branch_city, branch_mgr_email, branch_mgr_mobile, branch_mgr_name, channel_code, dob, email_id, errormessage, errormessagelist, first_name, initiative_cd, last_name, last_update_date, mobile_no, one_lakh_enable_flag, reg_date, reg_exp_date, register_flag, relaxed_days, terminate_flag) VALUES (3, '80001907', '120600', 'Kozhikode Branch Office', 'ajay.kundra@apollomunichinsurance.com', '9971995908', 'Ajay Kundra', NULL, '1973-06-15 00:00:00', 'shubham.batham@apollomunichinsurance.com', NULL, NULL, 'Shubham', NULL, '', NULL, '9896789993', NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO agent (id, users_id, branch, branch_city, branch_mgr_email, branch_mgr_mobile, branch_mgr_name, channel_code, dob, email_id, errormessage, errormessagelist, first_name, initiative_cd, last_name, last_update_date, mobile_no, one_lakh_enable_flag, reg_date, reg_exp_date, register_flag, relaxed_days, terminate_flag) VALUES (4, '80180146', '141300', 'Pondicherry Branch Office', 'ajay.kundra@apollomunichinsurance.com', '9971995908', 'Ajay Kundra', NULL, '1994-07-26 00:00:00', 'sabisingh071994@gmail.com', NULL, NULL, 'RAJASEKARAN R', NULL, '4', NULL, '9940303328', NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO agent (id, users_id, branch, branch_city, branch_mgr_email, branch_mgr_mobile, branch_mgr_name, channel_code, dob, email_id, errormessage, errormessagelist, first_name, initiative_cd, last_name, last_update_date, mobile_no, one_lakh_enable_flag, reg_date, reg_exp_date, register_flag, relaxed_days, terminate_flag) VALUES (1, '80091069', '900001', 'Gurgaon Head Office', 'mritunjay.singh@apollomunichinsurance.com', '9472733135', 'Mritunjay T Singh', NULL, '1981-07-15 00:00:00', 'sarkale.santosh1@gmail.com', NULL, NULL, 'Mr PORTAL .', NULL, '4', NULL, '7795004677', NULL, NULL, NULL, 0, NULL, NULL);
INSERT INTO agent (id, users_id, branch, branch_city, branch_mgr_email, branch_mgr_mobile, branch_mgr_name, channel_code, dob, email_id, errormessage, errormessagelist, first_name, initiative_cd, last_name, last_update_date, mobile_no, one_lakh_enable_flag, reg_date, reg_exp_date, register_flag, relaxed_days, terminate_flag) VALUES (2, '80091069', '900001', 'Gurgaon Head Office', 'mritunjay.singh@apollomunichinsurance.com', '9472733135', 'Mritunjay T Singh', NULL, '1981-07-15 00:00:00', 'sarkale.santosh1@gmail.com', NULL, NULL, 'Mr PORTAL .', NULL, '4', NULL, '7795004677', NULL, NULL, NULL, 0, NULL, NULL);


--
-- TOC entry 2161 (class 0 OID 100453)
-- Dependencies: 187
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 2175 (class 0 OID 0)
-- Dependencies: 186
-- Name: employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('employee_id_seq', 1, false);


--
-- TOC entry 2166 (class 0 OID 108731)
-- Dependencies: 192
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO feedback (id, productid, suminsured, disposition, comment, "time") VALUES (18, 5, 200000, 'Cold', 'Nice Product', '2017-06-09T10:32:04.218Z');
INSERT INTO feedback (id, productid, suminsured, disposition, comment, "time") VALUES (19, 5, 200000, 'Hot', 'Nice Product', '2017-06-09T10:46:44.572Z');
INSERT INTO feedback (id, productid, suminsured, disposition, comment, "time") VALUES (20, 5, 200000, 'Warm', '6+2=8', '2017-06-09T11:50:28.155Z');
INSERT INTO feedback (id, productid, suminsured, disposition, comment, "time") VALUES (21, 9, 10000000, 'Cold', 'Hfhfjgig', '2017-06-12T09:57:10.965Z');
INSERT INTO feedback (id, productid, suminsured, disposition, comment, "time") VALUES (22, 1, 400000, 'Cold', '', '2017-06-12T11:01:05.522Z');


--
-- TOC entry 2176 (class 0 OID 0)
-- Dependencies: 191
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('hibernate_sequence', 22, true);


--
-- TOC entry 2162 (class 0 OID 100459)
-- Dependencies: 188
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (13, 'Optima Cash', 10, 'segment_one', '500000', 'This book is a treatise on the theory of ethics, very popular during the Renaissance.
The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (16, 'Optima Cash', 10, 'segment_four', '1200000', 'Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC.');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (1, 'Optima Restore', 43, 'segment_one', '400000', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. ');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (7, 'Optima Super', 35, 'segment_three', '700000', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. ');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (12, 'Easy Health', 27, 'segment_four', '200000', 'Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC.');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (8, 'Optima Super', 35, 'segment_four', '800000', 'It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. ');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (9, 'Easy Health', 27, 'segment_one', '400000', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages and web page editors. ');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (2, 'Optima Restore', 43, 'segment_two', '200000', 'It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. ');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (11, 'Easy Health', 27, 'segment_three', '1000000', 'The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham. ');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (5, 'Optima Super', 35, 'segment_one', '300000', 'All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. ');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (14, 'Optima Cash', 10, 'segment_two', '800000', 'All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. ');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (15, 'Optima Cash', 10, 'segment_three', '500000', 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia. ');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (6, 'Optima Super', 35, 'segment_two', '600000', 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia. ');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (10, 'Easy Health', 27, 'segment_two', '800000', 'This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (4, 'Optima Restore', 43, 'segment_four', '900000', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages and web page editors. ');
INSERT INTO product (pid, product_name, product_priority, segments, sum_insured, sales_pitch) VALUES (3, 'Optima Restore', 43, 'segment_three', '400000', 'The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham. ');


--
-- TOC entry 2163 (class 0 OID 100464)
-- Dependencies: 189
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO questions (quesid, choose, question) VALUES (1, 'single', 'Please indicate your Occupation or occupation of the Chief Wage Earner of the Household');
INSERT INTO questions (quesid, choose, question) VALUES (2, 'multiple', 'Please indicate the assets owned by you/ your Household');
INSERT INTO questions (quesid, choose, question) VALUES (3, 'single', 'Monthly Household income');
INSERT INTO questions (quesid, choose, question) VALUES (4, 'single', 'Please indicate your Marital Status');
INSERT INTO questions (quesid, choose, question) VALUES (5, 'multiple', 'Please tell if the following health related behaviors are applicable to you');


--
-- TOC entry 2164 (class 0 OID 100472)
-- Dependencies: 190
-- Data for Name: questionsoptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (1, 'Skilled worker/Small Trader', 1, 1, 3, 4, 2, 5);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (2, 'Shop owner', 2, 1, 5, 4, 5, 6);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (3, 'Businessman/Industrialist', 3, 1, 3, 4, 3, 6);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (4, 'Self employed professional', 4, 1, 9, 9, 2, 3);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (5, 'Clerical/Salesman/Supervisor', 5, 1, 4, 8, 2, 2);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (6, 'Officer/Executive - Junior', 6, 1, 3, 7, 2, 6);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (7, 'Officer/Executive -Middle/Senior', 7, 1, 8, 4, 3, 2);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (8, 'Housewife', 8, 1, 4, 7, 2, 9);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (9, 'Student', 9, 1, 8, 4, 7, 6);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (10, 'Retired', 10, 1, 6, 8, 9, 5);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (11, 'Unemployed', 11, 1, 6, 3, 8, 7);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (12, 'Sedan Car', 1, 2, 2, 7, 2, 6);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (13, 'SUV Car', 2, 2, 7, 9, 3, 1);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (14, 'Hatchback Car -worth less than 5lakhs', 3, 2, 4, 6, 5, 9);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (15, 'Hatchback Car -worth more than 5lakhs', 4, 2, 6, 4, 2, 3);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (16, 'Smartphone worth less than 25000', 5, 2, 7, 9, 3, 1);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (17, 'Smartphone worth more than 25000', 6, 2, 4, 6, 5, 9);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (18, 'Air Conditioner (Window)', 7, 2, 7, 5, 2, 3);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (19, 'Air conditioner (Split)', 8, 2, 7, 2, 4, 3);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (20, 'Laptop/ tablet', 9, 2, 8, 4, 7, 6);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (21, 'Double door refrigerator', 10, 2, 6, 8, 9, 5);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (23, 'House', 11, 2, 6, 3, 8, 7);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (24, 'Fully automatic Washing machine', 12, 2, 5, 3, 4, 3);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (25, 'Semi-automatic washing machine', 13, 2, 8, 6, 4, 8);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (26, 'Motorbike (worth more than 1 lakh)', 14, 2, 5, 7, 3, 8);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (27, 'Credit Card', 15, 2, 6, 7, 2, 8);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (28, 'Personal Domestic Travel for vacations in last 1 year', 16, 2, 7, 6, 2, 8);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (29, 'Personal International Travel for vacations in last 2 years', 17, 2, 5, 7, 3, 8);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (30, 'Fitness club/sports complex membership', 18, 2, 6, 8, 2, 1);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (31, 'less than 30,000', 1, 3, 3, 6, 2, 5);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (32, '30,000 - 50,000', 2, 3, 6, 7, 2, 9);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (33, '50,000 to 1 lacs', 3, 3, 4, 2, 4, 9);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (34, '1 - 2 lacs', 4, 3, 2, 1, 6, 7);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (35, 'More than 2 lacs', 5, 3, 4, 8, 2, 2);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (37, 'Married without kids', 2, 4, 6, 8, 3, 2);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (38, 'Married with kids (oldest child in the age group of less than 12  years', 3, 4, 5, 3, 2, 5);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (39, 'Married with kids (oldest child in the age group of less than 13-18 years)', 4, 4, 1, 3, 5, 6);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (40, 'Married with kids (oldest child is more than 18 years old)', 5, 4, 2, 1, 4, 6);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (41, 'Widowed/divorced without Kids', 6, 4, 3, 5, 6, 7);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (42, 'Widowed/divorced with Kids', 7, 4, 3, 4, 9, 1);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (43, 'I do some physical activities', 1, 5, 2, 6, 1, 9);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (44, 'I take care of my food & nutrition', 2, 5, 6, 8, 3, 2);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (45, 'My normal work routine / household chores takes care of my health', 3, 5, 3, 2, 1, 6);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (46, 'I do indulge a little in food and drink because I believe it is good for health', 4, 5, 2, 4, 1, 6);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (47, 'I always check the nutritional content of food', 5, 5, 2, 1, 4, 6);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (48, 'I use organic food as far as possible', 6, 5, 2, 6, 7, 9);
INSERT INTO questionsoptions (id, option, optionid, quesid, segment_four, segment_one, segment_three, segment_two) VALUES (36, 'Single', 1, 4, 6, 5, 2, 8);


--
-- TOC entry 2029 (class 2606 OID 100450)
-- Name: agent agent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY agent
    ADD CONSTRAINT agent_pkey PRIMARY KEY (id);


--
-- TOC entry 2031 (class 2606 OID 100458)
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (id);


--
-- TOC entry 2041 (class 2606 OID 108738)
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- TOC entry 2035 (class 2606 OID 100463)
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY product
    ADD CONSTRAINT product_pkey PRIMARY KEY (pid);


--
-- TOC entry 2037 (class 2606 OID 100471)
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (quesid);


--
-- TOC entry 2039 (class 2606 OID 100476)
-- Name: questionsoptions questionsoptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY questionsoptions
    ADD CONSTRAINT questionsoptions_pkey PRIMARY KEY (id);


--
-- TOC entry 2033 (class 2606 OID 100478)
-- Name: employee uk_p136ambt19xg166m0jf37p7wn; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY employee
    ADD CONSTRAINT uk_p136ambt19xg166m0jf37p7wn UNIQUE (ssn);


-- Completed on 2017-06-13 10:32:15

--
-- PostgreSQL database dump complete
--

